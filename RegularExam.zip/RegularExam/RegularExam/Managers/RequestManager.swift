//
//  RequestManager.swift
//  RegularExam
//
//  Created by Hristo Papanov on 5.02.23.
//

import Foundation
import Alamofire

class RequestManager{
    /*static func fetchData(completion: @escaping((_ error: String?, _ result: [BlockbookSnapshot]?)->Void)){
     
     AF.request("https://btc.explorer.changex.io/api/", method: .get).responseDecodable (of: BlockbookResult.self)
     { (bitcoinDataResponse) in
     guard bitcoinDataResponse.error == nil else{
     completion(bitcoinDataResponse.error?.localizedDescription, nil)
     return
     }
     guard let responseValue = bitcoinDataResponse.value else{
     completion("No valid response", nil)
     return
     }
     completion(nil, Array(responseValue.result))
     }
     }*/
    
    static let url = URL(string: "https://btc.explorer.changex.io/api/")
    
    static var bestHeight: Int = 0
    
    class func fetchData() {
        var request = URLRequest(url: url!) //Create the URLRequest
        request.httpMethod = "GET" //Set the method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        // set the content type as there are APIs supporting multiple content types
        let task = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
            guard let data = data, let blockbook = try? JSONDecoder.snakeCaseDecoder.decode(BlockbookSnapshot.self, from: data) else {
                print("Incorrect format")
                return
            }
            print(blockbook)
            RequestManager.bestHeight = blockbook.bestHeight
            
            NotificationCenter.default.post(name: .newDataAvailable, object: nil)
            
        })
        task.resume()
    }
    
    class func fetchDataAlamofire() {
        let url = "https://btc.explorer.changex.io/api/"
        
        AF.request(url).responseDecodable(of: BlockbookSnapshot.self) { response in
            guard let blockbookData = response.value else {
                return
            }
            
            
            
            /* DispatchQueue.main.async {
             try? LocalDataManager.realm.write {
             LocalDataManager.realm.add(location, update: .all)
             }
             LocalDataManager.getWeatherData()
             }*/
            
            print(blockbookData)
        }
    }
}
