//
//  NotificationManager.swift
//  RegularExam
//
//  Created by Hristo Papanov on 5.02.23.
//

import Foundation

extension Notification.Name {
    static let newDataAvailable = Notification.Name("NewDataAvailableNotification")
}
