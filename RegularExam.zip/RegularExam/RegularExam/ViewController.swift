//
//  ViewController.swift
//  RegularExam
//
//  Created by Hristo Papanov on 5.02.23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //LocalDataManager.updateBlockbookData()
        // Do any additional setup after loading the view.
    }


}

