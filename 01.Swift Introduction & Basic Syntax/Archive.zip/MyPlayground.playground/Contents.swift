import UIKit

func surfaceOfTriangle(sideA: Float, heightA: Float) -> Float{
    let surface = (sideA*heightA)/2
    return(surface)
}

print(surfaceOfTriangle(sideA: 2.5, heightA: 3))


