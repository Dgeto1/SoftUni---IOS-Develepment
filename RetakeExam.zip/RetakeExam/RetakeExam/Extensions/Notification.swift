//
//  Notification.swift
//  RetakeExam
//
//  Created by Hristo Papanov on 12.02.23.
//

import Foundation

extension Notification.Name{
    static let dataUpdatedNotification = Notification.Name("dataUpdatedNotification")
}
