//
//  ViewController.swift
//  RetakeExam
//
//  Created by Hristo Papanov on 12.02.23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       // LocalDataManager.updateMarketData()
        // Do any additional setup after loading the view.
    }


}

